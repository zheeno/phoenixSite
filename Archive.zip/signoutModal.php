<div class="modal fade" id="signoutModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-md" role="document">
        <div class="container modal-content" style="padding-top:20px">
            <h3 class="h3-responsive">Sign Out</h3>
            <div class="center-align">
                <h5 class="h5-responsive">Are you sure you want to sign out?</h5>
            </div>
            <div class="md-form center-align" style="padding-top:20px">
                <a class="btn btn-outline-black deep-blue-border deep-blue-text capitalize btn-lg" data-dismiss="modal">No</a>
                <a class="sign-out-now-btn btn bg-deep-blue-grey white-text capitalize btn-lg">Yes</a>
            </div>
        </div>
    </div>
</div>